/* 铁皮盒贴贴 — 离线小工具主逻辑（ES2017 / Chrome 61 基线，经典脚本，无模块） */
(function () {
  'use strict';

  var W = 1080;
  var H = 1440;

  var canvas = document.getElementById('stage');
  var ctx = canvas.getContext('2d');
  var stageFrame = canvas.parentElement;
  var stageHint = document.getElementById('stage-hint');
  var fileInput = document.getElementById('file-input');
  var bgInput = document.getElementById('bg-input');
  var uploadInput = document.getElementById('upload-input');
  var toastEl = document.getElementById('toast');
  var sliderEl = document.getElementById('size-slider');
  var sliderValEl = document.getElementById('slider-val');
  var zoomLabelEl = document.getElementById('zoom-label');
  var stCountEl = document.getElementById('st-count');
  var stZoomEl = document.getElementById('st-zoom');
  var modalEl = document.getElementById('modal');
  var modalTitleEl = document.getElementById('modal-title');
  var modalInputEl = document.getElementById('modal-input');
  var modalHintEl = document.getElementById('modal-hint');
  var modalHelpEl = document.getElementById('modal-help');
  var modalExportEl = document.getElementById('modal-export');
  var exportPreviewEl = document.getElementById('export-preview');
  var materialsEl = document.getElementById('materials');

  /* ---------------- 状态 ---------------- */

  var state = { bg: 'bg_1', items: [] };
  var undoStack = [];
  var redoStack = [];
  var nextId = 1;
  var selectedId = null;
  var defaultScale = 1;
  var zoomPct = 100;
  var imgPool = {};
  var pendingFrame = null;
  var modalCb = null;
  var toastTimer = 0;

  var SPEC = {
    tin: { w: 860, h: 1025 },
    tile: { w: 92, h: 92 },
    stStar: { w: 150, h: 150 },
    stHeart: { w: 150, h: 150 },
    stSeal: { w: 130, h: 130 },
    stPetal: { w: 110, h: 150 },
    stBow: { w: 170, h: 120 },
    stKeychain: { w: 140, h: 200 },
    polaroid: { w: 300, h: 360 },
    rectpol: { w: 340, h: 260 },
    strip: { w: 220, h: 600 },
    heart: { w: 300, h: 290 },
    stamp: { w: 320, h: 360 },
    cam1: { w: 380, h: 379 },
    cam2: { w: 520, h: 337 },
    cam3: { w: 510, h: 334 }
  };

  /* ---------------- 工具函数 ---------------- */

  function deg2rad(d) { return d * Math.PI / 180; }

  function rr(c, x, y, w, h, r) {
    r = Math.min(r, w / 2, h / 2);
    c.beginPath();
    c.moveTo(x + r, y);
    c.lineTo(x + w - r, y);
    c.quadraticCurveTo(x + w, y, x + w, y + r);
    c.lineTo(x + w, y + h - r);
    c.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    c.lineTo(x + r, y + h);
    c.quadraticCurveTo(x, y + h, x, y + h - r);
    c.lineTo(x, y + r);
    c.quadraticCurveTo(x, y, x + r, y);
    c.closePath();
  }

  var BGS = ['bg_1', 'bg_2', 'bg_3', 'bg_4', 'bg_5', 'bg_6', 'bg_7', 'bg_8', 'bg_9', 'bg_10'];
  var bgAssets = {};
  var customBgImg = null;

  function preloadBgs() {
    for (var i = 0; i < BGS.length; i++) {
      var im = new Image();
      im.onload = render;
      im.src = './assets/bg/' + BGS[i] + '.jpg';
      bgAssets[BGS[i]] = im;
    }
  }

  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.hidden = false;
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.hidden = true; }, 1800);
  }

  function snapshot() {
    redoStack.length = 0;
    undoStack.push(JSON.stringify({ bg: state.bg, items: state.items }));
    if (undoStack.length > 30) undoStack.shift();
  }

  function undo() {
    if (!undoStack.length) { toast('没有可撤销的操作'); return; }
    redoStack.push(JSON.stringify({ bg: state.bg, items: state.items }));
    if (redoStack.length > 30) redoStack.shift();
    var data = JSON.parse(undoStack.pop());
    state.bg = data.bg;
    state.items = data.items;
    selectedId = null;
    syncBgSwatches();
    syncSlider();
    render();
  }

  function redo() {
    if (!redoStack.length) { toast('没有可重做的操作'); return; }
    undoStack.push(JSON.stringify({ bg: state.bg, items: state.items }));
    if (undoStack.length > 30) undoStack.shift();
    var data = JSON.parse(redoStack.pop());
    state.bg = data.bg;
    state.items = data.items;
    selectedId = null;
    syncBgSwatches();
    syncSlider();
    render();
  }

  function findItem(id) {
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].id === id) return state.items[i];
    }
    return null;
  }

  function selected() { return selectedId === null ? null : findItem(selectedId); }

  /* ---------------- 图片池 ---------------- */

  function registerUserImage(key, file) {
    var entry = { img: new Image(), loaded: false };
    entry.url = URL.createObjectURL(file);
    entry.img.onload = function () {
      entry.loaded = true;
      URL.revokeObjectURL(entry.url);
      entry.url = null;
      render();
    };
    entry.img.src = entry.url;
    imgPool[key] = entry;
    /* 存档用的小图放后台生成，照片先上画布 */
    decodeFile(file, function (err, src, w, h) {
      if (err) return;
      var cv = drawScaled(src, w, h);
      if (src.close) src.close();
      setTimeout(function () {
        userImageSrc[key] = assetDataUrl(cv);
        scheduleSave();
      }, 150);
    });
  }

  /* ---------------- 背景绘制 ---------------- */

  function drawBg(c) {
    c.fillStyle = '#f6f2ea';
    c.fillRect(0, 0, W, H);
    var im = state.bg === 'custom' ? customBgImg : bgAssets[state.bg];
    if (im && im.complete && im.naturalWidth > 0) {
      var sc = Math.max(W / im.naturalWidth, H / im.naturalHeight);
      var dw = im.naturalWidth * sc, dh = im.naturalHeight * sc;
      c.drawImage(im, (W - dw) / 2, (H - dh) / 2, dw, dh);
    }
  }

  /* ---------------- 元素绘制 ---------------- */

  var TIN_SPEC = {
    rect: { w: 860, h: 1025 },
    star: { w: 620, h: 930 },
    heart: { w: 560, h: 933 }
  };
  var tinAssets = {};

  function preloadTins() {
    var shapes = ['rect', 'star', 'heart'];
    for (var i = 0; i < shapes.length; i++) {
      var im = new Image();
      im.onload = render;
      im.src = './assets/tins/tin_' + shapes[i] + '.png';
      tinAssets[shapes[i]] = im;
    }
  }

  var CAM_KEYS = ['cam1', 'cam2', 'cam3'];
  var camAssets = {};
  /* 屏幕区域：相对相机图 [x, y, w, h] 归一化坐标，由抠图检测得到 */
  var CAM_SCREEN = {
    cam1: [0.1134, 0.2049, 0.5142, 0.6888],
    cam2: [0.0857, 0.2837, 0.5482, 0.6336],
    cam3: [0.0769, 0.3238, 0.4595, 0.5365]
  };

  function preloadCams() {
    for (var i = 0; i < CAM_KEYS.length; i++) {
      var im = new Image();
      im.onload = render;
      im.src = './assets/cam/' + CAM_KEYS[i] + '.png';
      camAssets[CAM_KEYS[i]] = im;
    }
  }

  function drawTin(c, item) {
    var im = tinAssets[item.shape];
    if (im && im.complete && im.naturalWidth > 0) {
      c.save();
      c.shadowColor = 'rgba(60,30,40,0.28)';
      c.shadowBlur = 14;
      c.shadowOffsetY = 8;
      c.drawImage(im, -item.w / 2, -item.h / 2, item.w, item.h);
      c.restore();
    } else {
      c.fillStyle = '#cfd4da';
      rr(c, -item.w / 2, -item.h / 2, item.w, item.h, 56);
      c.fill();
    }
  }

  var DECALS = ['star_text', 'kaomoji', 'bow', 'star_best', 'bubbles',
                'star_bloom', 'chat', 'heart_text', 'camera', 'patches',
                'license_cream', 'license_blue', 'license_purple',
                'stk_green', 'stk_grid', 'stk_blue',
                'stk_diamond_blue', 'stk_diamond_yellow', 'stk_red'];
  var decalAssets = {};

  function preloadDecals() {
    for (var i = 0; i < DECALS.length; i++) {
      var im = new Image();
      im.onload = render;
      im.src = './assets/decal/decal_' + DECALS[i] + '.png';
      decalAssets[DECALS[i]] = im;
    }
  }

  var SCRIPT_COLOR = '#b8518f';
  var LABEL_COLOR = '#c2689a';
  var LABEL_TEXT_COLOR = '#ffffff';

  var FONT_STACKS = {
    script: 'italic 700 {s}px "Brush Script MT", "Segoe Script", "Snell Roundhand", cursive',
    round: '700 {s}px "Arial Rounded MT Bold", "YouYuan", "幼圆", -apple-system, "Segoe UI", "PingFang SC", sans-serif',
    serif: '700 {s}px Georgia, "Times New Roman", "Songti SC", "SimSun", serif'
  };
  function itemFont(item, size) {
    var name = item.font || (item.kind === 'script' ? 'script' : 'round');
    return (FONT_STACKS[name] || FONT_STACKS.round).replace('{s}', size);
  }
  function labelFont(size) { return FONT_STACKS.round.replace('{s}', size); }

  var OBJS = ['earbud', 'airpods', 'case_pink', 'glasses', 'tape', 'cd',
              'clip1', 'clip2', 'clip3', 'clip4', 'pin1', 'pin2',
              'cardvert', 'cardhorz', 'phone',
              'charm', 'cherry', 'star', 'apple',
              'bow_mint', 'bow_pink', 'bow_navy',
              'btn_star', 'btn_heart', 'btn_cloud'];

  function preloadObjs() {
    for (var i = 0; i < OBJS.length; i++) {
      var im = new Image();
      im.onload = render;
      im.src = './assets/obj/obj_' + OBJS[i] + '.png';
      decalAssets['obj_' + OBJS[i]] = im;
    }
  }

  /* 素材图源可能是 Image 也可能是 canvas（上传素材直接用缩小后的画布） */
  function assetW(im) { return im ? (im.naturalWidth || im.width || 0) : 0; }
  function assetH(im) { return im ? (im.naturalHeight || im.height || 0) : 0; }

  function drawDecal(c, item) {
    var im = decalAssets[item.decal];
    if (assetW(im) > 0) {
      c.save();
      c.shadowColor = 'rgba(60,30,40,0.22)';
      c.shadowBlur = 10;
      c.shadowOffsetY = 6;
      c.drawImage(im, -item.w / 2, -item.h / 2, item.w, item.h);
      c.restore();
    } else {
      c.fillStyle = '#eee';
      c.fillRect(-item.w / 2, -item.h / 2, item.w, item.h);
    }
  }

  var BEADS = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
               'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
               'heart', 'star'];
  var tileAssets = {};

  function preloadTiles() {
    for (var i = 0; i < BEADS.length; i++) {
      var im = new Image();
      im.onload = render;
      im.src = './assets/tiles/tile_' + BEADS[i] + '.png';
      tileAssets[BEADS[i]] = im;
    }
  }

  function drawTile(c, item) {
    var im = tileAssets[item.ch];
    if (im && im.complete && im.naturalWidth > 0) {
      c.save();
      c.shadowColor = 'rgba(60,30,40,0.3)';
      c.shadowBlur = 8;
      c.shadowOffsetY = 5;
      c.drawImage(im, -46, -46, 92, 92);
      c.restore();
    } else {
      c.fillStyle = '#ffffff';
      rr(c, -46, -46, 92, 92, 46);
      c.fill();
    }
  }

  function starPath(c, rOut, rIn, points) {
    points = points || 5;
    c.beginPath();
    for (var i = 0; i < points * 2; i++) {
      var r = i % 2 === 0 ? rOut : rIn;
      var a = -Math.PI / 2 + i * Math.PI / points;
      var x = Math.cos(a) * r, y = Math.sin(a) * r;
      if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
    }
    c.closePath();
  }

  function heartPath(c, s) {
    c.beginPath();
    c.moveTo(0, s * 0.35);
    c.bezierCurveTo(-s * 0.9, -s * 0.25, -s * 0.45, -s * 0.85, 0, -s * 0.42);
    c.bezierCurveTo(s * 0.45, -s * 0.85, s * 0.9, -s * 0.25, 0, s * 0.35);
    c.closePath();
  }

  function drawSticker(c, item) {
    var k = item.kind;
    if (k === 'stStar') {
      starPath(c, 72, 30);
      c.fillStyle = '#f7d94c'; c.fill();
      c.strokeStyle = '#d9a520'; c.lineWidth = 5; c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.5)';
      c.beginPath(); c.arc(-14, -22, 9, 0, Math.PI * 2); c.fill();
    } else if (k === 'stHeart') {
      heartPath(c, 70);
      c.fillStyle = '#f76fa0'; c.fill();
      c.strokeStyle = '#d84a80'; c.lineWidth = 5; c.stroke();
      c.fillStyle = 'rgba(255,255,255,0.55)';
      c.beginPath(); c.ellipse(-20, -28, 12, 18, -0.5, 0, Math.PI * 2); c.fill();
    } else if (k === 'stSeal') {
      c.fillStyle = '#a32642';
      c.beginPath();
      for (var i = 0; i <= 24; i++) {
        var a = i / 24 * Math.PI * 2;
        var r = 62 + Math.sin(a * 12) * 6;
        var x = Math.cos(a) * r, y = Math.sin(a) * r;
        if (i === 0) c.moveTo(x, y); else c.lineTo(x, y);
      }
      c.closePath(); c.fill();
      c.fillStyle = '#8c1e38';
      c.beginPath(); c.arc(0, 0, 46, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#c05a78';
      for (var p = 0; p < 5; p++) {
        var pa = p * Math.PI * 2 / 5 - Math.PI / 2;
        c.beginPath();
        c.ellipse(Math.cos(pa) * 18, Math.sin(pa) * 18, 12, 8, pa, 0, Math.PI * 2);
        c.fill();
      }
      c.beginPath(); c.arc(0, 0, 8, 0, Math.PI * 2); c.fill();
    } else if (k === 'stPetal') {
      c.fillStyle = '#d8405a';
      c.beginPath();
      c.moveTo(0, -70);
      c.bezierCurveTo(60, -30, 48, 40, 0, 72);
      c.bezierCurveTo(-48, 40, -60, -30, 0, -70);
      c.closePath(); c.fill();
      c.strokeStyle = 'rgba(140,20,40,0.5)'; c.lineWidth = 3;
      c.beginPath(); c.moveTo(0, -50); c.lineTo(0, 55); c.stroke();
    } else if (k === 'stBow') {
      c.fillStyle = '#e0446a';
      c.beginPath();
      c.moveTo(-12, 0);
      c.bezierCurveTo(-70, -46, -78, 30, -14, 16);
      c.closePath(); c.fill();
      c.beginPath();
      c.moveTo(12, 0);
      c.bezierCurveTo(70, -46, 78, 30, 14, 16);
      c.closePath(); c.fill();
      c.beginPath();
      c.moveTo(-6, 12); c.lineTo(-26, 62); c.lineTo(-6, 58); c.lineTo(2, 20);
      c.closePath(); c.fill();
      c.beginPath();
      c.moveTo(6, 12); c.lineTo(28, 62); c.lineTo(8, 58); c.lineTo(0, 20);
      c.closePath(); c.fill();
      c.fillStyle = '#c22a52';
      c.beginPath(); c.arc(0, 4, 16, 0, Math.PI * 2); c.fill();
    } else if (k === 'stKeychain') {
      c.strokeStyle = '#9aa1aa'; c.lineWidth = 7;
      c.beginPath(); c.arc(0, -78, 22, 0, Math.PI * 2); c.stroke();
      c.beginPath(); c.moveTo(0, -56); c.lineTo(0, -34); c.stroke();
      c.save();
      c.translate(0, 26);
      starPath(c, 62, 26);
      c.fillStyle = '#f7d94c'; c.fill();
      c.strokeStyle = '#d9a520'; c.lineWidth = 5; c.stroke();
      c.restore();
    }
  }

  function drawPhotoCover(c, item, x, y, w, h, photo) {
    var entry = imgPool[item.imgKey];
    if (!entry || !entry.loaded) {
      c.fillStyle = '#f0e2e9';
      c.fillRect(x, y, w, h);
      c.fillStyle = '#c99cb4';
      c.font = '400 26px sans-serif';
      c.textAlign = 'center'; c.textBaseline = 'middle';
      c.fillText('加载中…', x + w / 2, y + h / 2);
      return;
    }
    var img = entry.img;
    var ir = img.width / img.height, br = w / h;
    var sw = img.width, sh = img.height, sx = 0, sy = 0;
    if (ir > br) { sw = img.height * br; sx = (img.width - sw) / 2; }
    else { sh = img.width / br; sy = (img.height - sh) / 2; }
    if (photo && photo.z > 1) {
      var z = Math.min(3, Math.max(1, photo.z));
      var nw = sw / z, nh = sh / z;
      /* 照片内偏移：手指向右 → 画面内容向右（取景窗口反向移动），并钳制在图像范围内 */
      var px = (photo.ox || 0) * (nw / w);
      var py = (photo.oy || 0) * (nh / h);
      sx = Math.min(img.width - nw, Math.max(0, sx + (sw - nw) / 2 - px));
      sy = Math.min(img.height - nh, Math.max(0, sy + (sh - nh) / 2 - py));
      sw = nw; sh = nh;
    }
    c.save();
    c.beginPath(); c.rect(x, y, w, h); c.clip();
    c.drawImage(img, sx, sy, sw, sh, x, y, w, h);
    c.restore();
  }

  function stampPath(c, hw, hh, r, nx, ny) {
    var dx = (hw * 2) / nx, dy = (hh * 2) / ny;
    var i, x, y;
    c.beginPath();
    c.moveTo(-hw, -hh);
    for (i = 1; i < nx; i++) {
      x = -hw + i * dx;
      c.lineTo(x - r, -hh);
      c.arc(x, -hh, r, Math.PI, 0, true);
    }
    for (i = 1; i < ny; i++) {
      y = -hh + i * dy;
      c.lineTo(hw, y - r);
      c.arc(hw, y, r, -Math.PI / 2, Math.PI / 2, true);
    }
    c.lineTo(hw, hh);
    for (i = nx - 1; i >= 1; i--) {
      x = -hw + i * dx;
      c.lineTo(x + r, hh);
      c.arc(x, hh, r, 0, Math.PI, true);
    }
    c.lineTo(-hw, hh);
    for (i = ny - 1; i > 0; i--) {
      y = -hh + i * dy;
      c.lineTo(-hw, y + r);
      c.arc(-hw, y, r, Math.PI / 2, -Math.PI / 2, true);
    }
    c.closePath();
  }

  function drawPhotoFrame(c, item) {
    var k = item.kind;
    if (k === 'cam1' || k === 'cam2' || k === 'cam3') {
      var imc = camAssets[k];
      if (imc && imc.complete && imc.naturalWidth > 0) {
        c.save();
        c.shadowColor = 'rgba(60,30,40,0.25)';
        c.shadowBlur = 12;
        c.shadowOffsetY = 7;
        c.drawImage(imc, -item.w / 2, -item.h / 2, item.w, item.h);
        c.restore();
      } else {
        c.fillStyle = '#dfe3e8';
        rr(c, -item.w / 2, -item.h / 2, item.w, item.h, 24);
        c.fill();
      }
      var sr = CAM_SCREEN[k];
      drawPhotoCover(c, item,
        -item.w / 2 + sr[0] * item.w, -item.h / 2 + sr[1] * item.h,
        sr[2] * item.w, sr[3] * item.h, item.photo);
      return;
    }
    if (k === 'rectpol') {
      c.fillStyle = 'rgba(60,30,40,0.25)';
      rr(c, -170 + 5, -130 + 7, 340, 260, 10); c.fill();
      c.fillStyle = '#ffffff';
      rr(c, -170, -130, 340, 260, 10); c.fill();
      drawPhotoCover(c, item, -154, -114, 308, 228, item.photo);
      c.strokeStyle = '#e8dfe3'; c.lineWidth = 2;
      c.strokeRect(-154, -114, 308, 228);
    } else if (k === 'polaroid') {
      c.fillStyle = 'rgba(60,30,40,0.25)';
      rr(c, -150 + 5, -180 + 7, 300, 360, 10); c.fill();
      c.fillStyle = '#ffffff';
      rr(c, -150, -180, 300, 360, 10); c.fill();
      drawPhotoCover(c, item, -132, -162, 264, 264, item.photo);
      c.strokeStyle = '#e8dfe3'; c.lineWidth = 2;
      c.strokeRect(-132, -162, 264, 264);
    } else if (k === 'strip') {
      c.fillStyle = 'rgba(60,30,40,0.25)';
      rr(c, -110 + 5, -300 + 7, 220, 600, 12); c.fill();
      c.fillStyle = '#ffffff';
      rr(c, -110, -300, 220, 600, 12); c.fill();
      for (var i = 0; i < 3; i++) {
        var sub = { imgKey: (item.imgKeys && item.imgKeys[i]) || item.imgKey };
        drawPhotoCover(c, sub, -90, -280 + i * 196, 180, 180, item.photo);
      }
    } else if (k === 'stamp') {
      c.save();
      c.translate(5, 7);
      c.fillStyle = 'rgba(60,30,40,0.22)';
      stampPath(c, 160, 180, 13, 8, 9);
      c.fill();
      c.restore();
      c.fillStyle = '#fdfaf6';
      stampPath(c, 160, 180, 13, 8, 9);
      c.fill();
      drawPhotoCover(c, item, -128, -148, 256, 296, item.photo);
      c.strokeStyle = 'rgba(180,160,170,0.45)';
      c.lineWidth = 2;
      c.strokeRect(-128, -148, 256, 296);
    } else if (k === 'heart') {
      c.save();
      heartPath(c, 130);
      c.clip();
      drawPhotoCover(c, item, -120, -120, 240, 240, item.photo);
      c.restore();
      heartPath(c, 130);
      c.strokeStyle = '#f76fa0'; c.lineWidth = 14; c.stroke();
      heartPath(c, 130);
      c.strokeStyle = 'rgba(255,255,255,0.7)'; c.lineWidth = 4; c.stroke();
    }
  }

  function drawTextItem(c, item) {
    if (item.kind === 'script') {
      c.font = itemFont(item, 116);
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.shadowColor = 'rgba(180,80,130,0.4)';
      c.shadowBlur = 8;
      c.shadowOffsetY = 4;
      c.fillStyle = item.color || SCRIPT_COLOR;
      c.fillText(item.text, 0, 0);
      c.shadowColor = 'transparent';
      c.shadowBlur = 0;
      c.shadowOffsetY = 0;
    } else if (item.kind === 'label') {
      var shape = item.shape || 'rect';
      var hw = item.w / 2, hh = item.h / 2;
      var badge = shape === 'heart' || shape === 'star';
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.fillStyle = item.color || LABEL_COLOR;
      if (shape === 'pill') {
        rr(c, -hw, -hh, item.w, item.h, hh); c.fill();
      } else if (shape === 'bubble') {
        rr(c, -hw, -item.h / 2, item.w, item.h - 24, 14); c.fill();
        c.beginPath();
        c.moveTo(-hw + 20, item.h / 2 - 24);
        c.lineTo(-hw + 38, item.h / 2 - 24);
        c.lineTo(-hw + 22, item.h / 2);
        c.closePath(); c.fill();
      } else if (shape === 'heart') {
        c.save();
        c.translate(0, item.h * 0.12);
        c.scale(item.w / 104, item.h / 92);
        heartPath(c, 100);
        c.fill();
        c.restore();
      } else if (shape === 'star') {
        starPath(c, hw, hw * 0.82, 12);
        c.fill();
      } else {
        rr(c, -hw, -34, item.w, 68, 14); c.fill();
      }
      var dy = 2;
      if (shape === 'bubble') dy = -12;
      else if (shape === 'heart') dy = -item.h * 0.18;
      else if (shape === 'star') dy = 0;
      var fs = 36;
      if (badge) {
        c.font = itemFont(item, 36);
        var tw = c.measureText(item.text).width;
        if (tw > item.w * 0.8) fs = Math.max(18, Math.floor(36 * item.w * 0.8 / tw));
      }
      c.fillStyle = item.textColor || LABEL_TEXT_COLOR;
      c.font = itemFont(item, fs);
      c.fillText(item.text, 0, dy);
    }
  }

  function measureTextItem(kind, text, font) {
    ctx.save();
    var w;
    if (kind === 'script') {
      ctx.font = (FONT_STACKS[font || 'script'] || FONT_STACKS.script).replace('{s}', 116);
      w = ctx.measureText(text).width + 40;
    } else {
      ctx.font = (FONT_STACKS[font || 'round'] || FONT_STACKS.round).replace('{s}', 36);
      w = ctx.measureText(text).width + 44;
    }
    ctx.restore();
    return Math.max(80, w);
  }

  function drawItem(c, item) {
    c.save();
    c.translate(item.x, item.y);
    c.rotate(deg2rad(item.r));
    c.scale(item.s, item.s);
    var k = item.kind;
    if (k === 'tin') drawTin(c, item);
    else if (k === 'decal') drawDecal(c, item);
    else if (k === 'tile') drawTile(c, item);
    else if (k === 'rectpol' || k === 'polaroid' || k === 'strip' || k === 'heart' || k === 'stamp' ||
             k === 'cam1' || k === 'cam2' || k === 'cam3') drawPhotoFrame(c, item);
    else if (k.indexOf('st') === 0) drawSticker(c, item);
    else drawTextItem(c, item);
    if (item.id === selectedId) {
      c.strokeStyle = '#ff4f8b';
      c.lineWidth = 4 / item.s;
      c.setLineDash([12 / item.s, 9 / item.s]);
      rr(c, -item.w / 2 - 8, -item.h / 2 - 8, item.w + 16, item.h + 16, 12);
      c.stroke();
      c.setLineDash([]);
    }
    c.restore();
  }

  var lastRenderedCount = -1;

  function render() {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, W, H);
    drawBg(ctx);
    for (var i = 0; i < state.items.length; i++) drawItem(ctx, state.items[i]);
    var selItem = selected();
    if (selItem) drawSelection(ctx, selItem);
    /* DOM 只在数量变化时更新，避免每帧触发布局 */
    if (state.items.length !== lastRenderedCount) {
      lastRenderedCount = state.items.length;
      stCountEl.textContent = String(state.items.length);
      stageHint.hidden = state.items.length > 0;
    }
    scheduleSave();
  }

  /* 拖动/缩放中的重绘合并到每帧一次，避免高频 pointermove 卡顿 */
  var renderPending = false;
  function scheduleRender() {
    if (renderPending) return;
    renderPending = true;
    requestAnimationFrame(function () {
      renderPending = false;
      render();
    });
  }

  function drawSelection(c, item) {
    c.save();
    c.translate(item.x, item.y);
    c.rotate(deg2rad(item.r));
    c.scale(item.s, item.s);
    var hw = item.w / 2 + 8, hh = item.h / 2 + 8;
    c.strokeStyle = '#f06292';
    c.lineWidth = 4;
    c.setLineDash([16, 10]);
    c.strokeRect(-hw, -hh, hw * 2, hh * 2);
    c.setLineDash([]);
    c.fillStyle = '#f06292';
    var corners = [[-hw, -hh], [hw, -hh], [-hw, hh], [hw, hh]];
    for (var i = 0; i < 4; i++) {
      c.beginPath();
      c.arc(corners[i][0], corners[i][1], 9, 0, Math.PI * 2);
      c.fill();
    }
    c.restore();
  }

  /* ---------------- 元素创建 ---------------- */

  function jitter() { return (Math.random() - 0.5) * 120; }

  function addItem(kind, extra) {
    var spec = SPEC[kind];
    var item = {
      id: nextId++,
      kind: kind,
      x: W / 2 + jitter(),
      y: H / 2 + jitter(),
      r: Math.round((Math.random() - 0.5) * 16),
      s: defaultScale,
      w: spec ? spec.w : 100,
      h: spec ? spec.h : 100
    };
    if (extra) {
      for (var key in extra) {
        if (Object.prototype.hasOwnProperty.call(extra, key)) item[key] = extra[key];
      }
    }
    snapshot();
    state.items.push(item);
    selectedId = item.id;
    syncSlider();
    render();
    return item;
  }

  /* ---------------- 命中与手势 ---------------- */

  /* 手势期间缓存画布位置，避免每次 move 触发 getBoundingClientRect 重排 */
  var cachedRect = null;

  function toCanvasPoint(clientX, clientY) {
    if (!cachedRect) cachedRect = canvas.getBoundingClientRect();
    return {
      x: (clientX - cachedRect.left) * W / cachedRect.width,
      y: (clientY - cachedRect.top) * H / cachedRect.height
    };
  }

  function hitTest(p) {
    for (var i = state.items.length - 1; i >= 0; i--) {
      var it = state.items[i];
      var dx = p.x - it.x, dy = p.y - it.y;
      var a = -deg2rad(it.r);
      var lx = (dx * Math.cos(a) - dy * Math.sin(a)) / it.s;
      var ly = (dx * Math.sin(a) + dy * Math.cos(a)) / it.s;
      if (Math.abs(lx) <= it.w / 2 + 6 && Math.abs(ly) <= it.h / 2 + 6) return it;
    }
    return null;
  }

  /* 点按穿透：找指定元素之下的、同点位命中的元素（用于再点一下选中被压住的下层） */
  function hitTestBelow(p, above) {
    var end = state.items.indexOf(above);
    for (var i = end - 1; i >= 0; i--) {
      var it = state.items[i];
      var dx = p.x - it.x, dy = p.y - it.y;
      var a = -deg2rad(it.r);
      var lx = (dx * Math.cos(a) - dy * Math.sin(a)) / it.s;
      var ly = (dx * Math.sin(a) + dy * Math.cos(a)) / it.s;
      if (Math.abs(lx) <= it.w / 2 + 6 && Math.abs(ly) <= it.h / 2 + 6) return it;
    }
    return null;
  }

  var pointers = {};
  var pointerCount = 0;
  var drag = null;   /* {item, offX, offY, moved} 或照片模式 {item, photoMode, sx, sy, ox0, oy0, moved} */
  var pinch = null;  /* {item, d0, a0, s0, r0} */
  var photoPinch = null; /* {item, d0, pz0} 照片缩放双指 */

  function isFrameKind(k) {
    return k === 'rectpol' || k === 'polaroid' || k === 'strip' || k === 'heart' || k === 'stamp' ||
           k === 'cam1' || k === 'cam2' || k === 'cam3';
  }

  function ensurePhoto(it) {
    if (!it.photo) it.photo = { z: 1, ox: 0, oy: 0 };
    return it.photo;
  }

  function onDown(e) {
    e.preventDefault();
    cachedRect = canvas.getBoundingClientRect();
    var p = toCanvasPoint(e.clientX, e.clientY);
    pointers[e.pointerId] = { x: p.x, y: p.y, cx: e.clientX, cy: e.clientY };
    pointerCount++;
    canvas.setPointerCapture(e.pointerId);

    var it = hitTest(p);
    if (it) {
      /* 是否点了已选中的元素：轻点不拖动时用于穿透选中下层 */
      var tapCycle = (it.id === selectedId) && pointerCount === 1;
      selectedId = it.id;
      syncSlider();
      if (pointerCount === 1) {
        if (photoEdit && isFrameKind(it.kind) && it.photo) {
          /* 照片编辑模式：拖动平移相框内照片 */
          drag = { item: it, photoMode: true, sx: p.x, sy: p.y, ox0: it.photo.ox || 0, oy0: it.photo.oy || 0, moved: false, tapCycle: false };
        } else {
          drag = { item: it, offX: p.x - it.x, offY: p.y - it.y, moved: false, sx: p.x, sy: p.y, tapCycle: tapCycle };
        }
      } else if (pointerCount === 2 && drag && drag.item === it) {
        var ids = Object.keys(pointers);
        var p1 = pointers[ids[0]], p2 = pointers[ids[1]];
        if (drag.photoMode) {
          photoPinch = {
            item: it,
            d0: Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2)),
            pz0: it.photo.z
          };
        } else {
          pinch = {
            item: it,
            d0: Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2)),
            a0: Math.atan2(p2.y - p1.y, p2.x - p1.x),
            s0: it.s, r0: it.r
          };
        }
        drag.moved = true;
      }
    } else {
      selectedId = null;
      syncSlider();
    }
    render();
  }

  function onMove(e) {
    if (!pointers[e.pointerId]) return;
    var p = toCanvasPoint(e.clientX, e.clientY);
    pointers[e.pointerId] = { x: p.x, y: p.y, cx: e.clientX, cy: e.clientY };

    if (photoPinch && pointerCount >= 2) {
      var pds = Object.keys(pointers);
      var pd1 = pointers[pds[0]], pd2 = pointers[pds[1]];
      var pd = Math.sqrt(Math.pow(pd2.x - pd1.x, 2) + Math.pow(pd2.y - pd1.y, 2));
      var pit = photoPinch.item;
      var ph = ensurePhoto(pit);
      ph.z = Math.min(3, Math.max(1, photoPinch.pz0 * pd / photoPinch.d0));
      if (ph.z <= 1) { ph.ox = 0; ph.oy = 0; }
      syncSlider();
      scheduleRender();
      return;
    }

    if (pinch && pointerCount >= 2) {
      var ids = Object.keys(pointers);
      var p1 = pointers[ids[0]], p2 = pointers[ids[1]];
      var d = Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
      var ang = Math.atan2(p2.y - p1.y, p2.x - p1.x);
      var it = pinch.item;
      it.s = Math.min(3, Math.max(0.2, pinch.s0 * d / pinch.d0));
      it.r = pinch.r0 + Math.round((ang - pinch.a0) * 180 / Math.PI);
      syncSlider();
      scheduleRender();
      return;
    }

    if (drag && pointerCount === 1) {
      var item = drag.item;
      if (drag.photoMode) {
        /* 照片模式：画布位移 → 元素本地坐标（考虑旋转与缩放） */
        if (!item.photo) item.photo = { z: 1, ox: 0, oy: 0 };
        var ddx = p.x - drag.sx, ddy = p.y - drag.sy;
        var a = -deg2rad(item.r);
        var lx = (ddx * Math.cos(a) - ddy * Math.sin(a)) / item.s;
        var ly = (ddx * Math.sin(a) + ddy * Math.cos(a)) / item.s;
        item.photo.ox = drag.ox0 + lx;
        item.photo.oy = drag.oy0 + ly;
        if (!drag.moved && Math.abs(ddx) + Math.abs(ddy) > 4) {
          snapshot();
          drag.moved = true;
        }
        scheduleRender();
        return;
      }
      item.x = p.x - drag.offX;
      item.y = p.y - drag.offY;
      if (!drag.moved && Math.abs(p.x - drag.sx) + Math.abs(p.y - drag.sy) > 4) {
        snapshot();
        drag.moved = true;
      }
      scheduleRender();
    }
  }

  function onUp(e) {
    if (!pointers[e.pointerId]) return;
    delete pointers[e.pointerId];
    pointerCount = Math.max(0, pointerCount - 1);

    if (drag && pointerCount === 0) {
      /* 轻点已选中的元素且没拖动 → 穿透选中压在下面的那层 */
      if (drag.tapCycle && !drag.moved) {
        var under = hitTestBelow({ x: drag.sx, y: drag.sy }, drag.item);
        if (under) { selectedId = under.id; syncSlider(); }
      }
      drag = null;
      pinch = null;
      photoPinch = null;
      cachedRect = null;
      render();
      return;
    }
    if ((pinch || photoPinch) && pointerCount < 2) {
      pinch = null;
      photoPinch = null;
      drag = null;
      cachedRect = null;
    }
  }

  function removeItem(id) {
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].id === id) { state.items.splice(i, 1); break; }
    }
    if (selectedId === id) selectedId = null;
  }

  /* 拖动前记录快照以便撤销位置 */
  canvas.addEventListener('pointerdown', onDown);
  canvas.addEventListener('pointermove', onMove);
  canvas.addEventListener('pointerup', onUp);
  canvas.addEventListener('pointercancel', onUp);

  /* ---------------- 滑杆 / 缩放 ---------------- */

  var rotateRow = document.getElementById('rotate-row');
  var rotateSlider = document.getElementById('rotate-slider');
  var rotateValEl = document.getElementById('rotate-val');
  var rotateDirty = false;

  var colorRow = document.getElementById('color-row');
  var colorDots = document.getElementById('color-dots');
  var colorDirty = false;
  var labelbgRow = document.getElementById('labelbg-row');
  var labelbgDots = document.getElementById('labelbg-dots');
  var labelbgDirty = false;
  var labeltextRow = document.getElementById('labeltext-row');
  var labeltextDots = document.getElementById('labeltext-dots');
  var labeltextDirty = false;
  var labelshapeRow = document.getElementById('labelshape-row');
  var shapeBtns = [].slice.call(document.querySelectorAll('#labelshape-dots .shape-btn'));
  var shapeDirty = false;

  var fontRow = document.getElementById('font-row');
  var fontBtns = [].slice.call(document.querySelectorAll('#font-dots .font-btn'));
  var fontDirty = false;

  var photoRow = document.getElementById('photo-row');
  var photoSlider = document.getElementById('photo-slider');
  var photoValEl = document.getElementById('photo-val');
  var photoMoveBtn = document.getElementById('photo-move-btn');
  var photoEdit = false;
  var photoEditItemId = null;
  var photoDirty = false;

  var layerRow = document.getElementById('layer-row');
  var layerUpBtn = document.getElementById('layer-up-btn');
  var layerDownBtn = document.getElementById('layer-down-btn');
  var layerTopBtn = document.getElementById('layer-top-btn');

  /* 图层调整：数组越靠后越在上层；delta 1=上移一层 -1=下移一层 Infinity=置顶 */
  function moveLayer(delta) {
    var it = selected();
    if (!it) { toast('先点选一个元素'); return; }
    var idx = state.items.indexOf(it);
    var ni = delta === Infinity ? state.items.length - 1 : idx + delta;
    if (ni < 0 || ni >= state.items.length || ni === idx) return;
    snapshot();
    state.items.splice(idx, 1);
    state.items.splice(ni, 0, it);
    render();
  }

  function markActiveDots(wrap, cur) {
    if (!wrap || !wrap.querySelectorAll) return;
    var dots = wrap.querySelectorAll('.color-dot');
    for (var i = 0; i < dots.length; i++) {
      var on = dots[i].getAttribute('data-color') === cur;
      dots[i].className = on ? 'color-dot is-active' : 'color-dot';
    }
  }

  function labelHeight(shape, w) {
    if (shape === 'heart') return Math.round(w * 0.88);
    if (shape === 'star') return w;
    return shape === 'bubble' ? 92 : 68;
  }

  function normDeg(d) { return ((d % 360) + 540) % 360 - 180; }

  function syncSlider() {
    var it = selected();
    rotateRow.hidden = !it;
    var isScript = !!it && it.kind === 'script';
    var isLabel = !!it && it.kind === 'label';
    var isFrame = !!it && isFrameKind(it.kind);
    colorRow.hidden = !isScript;
    labelbgRow.hidden = !isLabel;
    labeltextRow.hidden = !isLabel;
    labelshapeRow.hidden = !isLabel;
    /* 字体行：花体标题 / 短句标签通用 */
    var isText = isScript || isLabel;
    fontRow.hidden = !isText;
    if (isText) {
      fontDirty = false;
      var curFont = it.font || (isScript ? 'script' : 'round');
      for (var fi = 0; fi < fontBtns.length; fi++) {
        fontBtns[fi].className = fontBtns[fi].getAttribute('data-font') === curFont
          ? 'font-btn is-active' : 'font-btn';
      }
    }
    /* 照片编辑模式：切换选中对象时自动退出 */
    if (!isFrame || !it || it.id !== photoEditItemId) {
      photoEdit = false;
      photoEditItemId = it ? it.id : null;
    }
    photoRow.hidden = !isFrame;
    layerRow.hidden = !it;
    if (isFrame) {
      photoDirty = false;
      var ph = it.photo || { z: 1, ox: 0, oy: 0 };
      photoSlider.value = String(Math.min(300, Math.max(100, Math.round(ph.z * 100))));
      photoValEl.textContent = photoSlider.value + '%';
      photoMoveBtn.className = photoEdit ? 'tool-btn tool-btn-primary' : 'tool-btn';
      photoMoveBtn.textContent = photoEdit ? '调整中…' : '移动照片';
    }
    if (isScript) {
      colorDirty = false;
      markActiveDots(colorDots, it.color || SCRIPT_COLOR);
    }
    if (isLabel) {
      labelbgDirty = false;
      labeltextDirty = false;
      shapeDirty = false;
      markActiveDots(labelbgDots, it.color || LABEL_COLOR);
      markActiveDots(labeltextDots, it.textColor || LABEL_TEXT_COLOR);
      var curShape = it.shape || 'rect';
      for (var s = 0; s < shapeBtns.length; s++) {
        shapeBtns[s].className = shapeBtns[s].getAttribute('data-shape') === curShape
          ? 'shape-btn is-active' : 'shape-btn';
      }
    }
    var v = it ? Math.round(it.s * 100) : parseInt(sliderEl.value, 10);
    sliderEl.value = String(Math.min(250, Math.max(30, v)));
    sliderValEl.textContent = sliderEl.value + '%';
    if (it) {
      rotateDirty = false;
      rotateSlider.value = String(normDeg(Math.round(it.r)));
      rotateValEl.textContent = rotateSlider.value + '°';
    }
  }

  /* 扩展色板：17 常用色 + 自定义取色器 */
  var PALETTE = ['#c2689a', '#f06292', '#f4a6b8', '#ff8fab',
                 '#d43d51', '#e8654f', '#e0a52c', '#f7d94c',
                 '#a8cf45', '#3f8f6b', '#6ecfb0', '#22d3ee',
                 '#3d5a99', '#7d9bd8', '#7a5ba6', '#3a3335', '#ffffff'];
  var customColorInput = document.getElementById('custom-color');
  var customPick = null;

  function buildColorDots(container, onPick) {
    container.innerHTML = '';
    for (var i = 0; i < PALETTE.length; i++) {
      (function (col) {
        var b = document.createElement('button');
        b.type = 'button';
        b.className = 'color-dot';
        b.setAttribute('data-color', col);
        b.style.background = col;
        b.addEventListener('click', function () { onPick(col); });
        container.appendChild(b);
      })(PALETTE[i]);
    }
    var cbtn = document.createElement('button');
    cbtn.type = 'button';
    cbtn.className = 'color-dot color-dot-custom';
    cbtn.setAttribute('data-color', 'custom');
    cbtn.setAttribute('aria-label', '自定义颜色');
    cbtn.addEventListener('click', function () {
      customPick = onPick;
      customColorInput.click();
    });
    container.appendChild(cbtn);
  }

  function pickColor(getIt, prop, def, flag, col) {
    var it = getIt();
    if (!it) return;
    if ((it[prop] || def) === col) return;
    if (!flag.v) { snapshot(); flag.v = true; }
    it[prop] = col;
    syncSlider();
    render();
  }
  buildColorDots(colorDots, function (col) {
    pickColor(function () {
      var it = selected();
      return it && it.kind === 'script' ? it : null;
    }, 'color', SCRIPT_COLOR, { get v() { return colorDirty; }, set v(x) { colorDirty = x; } }, col);
  });
  buildColorDots(labelbgDots, function (col) {
    pickColor(function () {
      var it = selected();
      return it && it.kind === 'label' ? it : null;
    }, 'color', LABEL_COLOR, { get v() { return labelbgDirty; }, set v(x) { labelbgDirty = x; } }, col);
  });
  buildColorDots(labeltextDots, function (col) {
    pickColor(function () {
      var it = selected();
      return it && it.kind === 'label' ? it : null;
    }, 'textColor', LABEL_TEXT_COLOR, { get v() { return labeltextDirty; }, set v(x) { labeltextDirty = x; } }, col);
  });
  customColorInput.addEventListener('input', function () {
    if (customPick) customPick(customColorInput.value);
  });

  shapeBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var it = selected();
      if (!it || it.kind !== 'label') return;
      var sh = btn.getAttribute('data-shape');
      if ((it.shape || 'rect') === sh) return;
      if (!shapeDirty) { snapshot(); shapeDirty = true; }
      it.shape = sh;
      it.h = labelHeight(sh, it.w);
      syncSlider();
      render();
    });
  });

  fontBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var it = selected();
      if (!it || (it.kind !== 'script' && it.kind !== 'label')) return;
      var f = btn.getAttribute('data-font');
      if ((it.font || (it.kind === 'script' ? 'script' : 'round')) === f) return;
      if (!fontDirty) { snapshot(); fontDirty = true; }
      it.font = f;
      if (it.kind === 'script') it.w = measureTextItem('script', it.text, f);
      syncSlider();
      render();
    });
  });

  rotateSlider.addEventListener('input', function () {
    var it = selected();
    if (!it) return;
    if (!rotateDirty) { snapshot(); rotateDirty = true; }
    it.r = parseInt(rotateSlider.value, 10);
    rotateValEl.textContent = rotateSlider.value + '°';
    render();
  });
  rotateSlider.addEventListener('change', function () {
    rotateDirty = false;
  });

  photoSlider.addEventListener('input', function () {
    var it = selected();
    if (!it || !isFrameKind(it.kind)) return;
    if (!photoDirty) { snapshot(); photoDirty = true; }
    var ph = ensurePhoto(it);
    ph.z = parseInt(photoSlider.value, 10) / 100;
    if (ph.z <= 1) { ph.ox = 0; ph.oy = 0; }
    photoValEl.textContent = photoSlider.value + '%';
    render();
  });
  photoSlider.addEventListener('change', function () {
    photoDirty = false;
  });

  photoMoveBtn.addEventListener('click', function () {
    var it = selected();
    if (!it || !isFrameKind(it.kind)) return;
    photoEdit = !photoEdit;
    photoEditItemId = it.id;
    if (photoEdit) {
      var ph = ensurePhoto(it);
      if (ph.z <= 1) {
        /* 100% 时照片铺满相框、没有移动余量，自动放大让拖动立刻生效 */
        ph.z = 1.3;
        ph.ox = 0; ph.oy = 0;
        photoSlider.value = '130';
        photoValEl.textContent = '130%';
      }
      toast('拖动调整照片位置，双指缩放照片');
    } else {
      ensurePhoto(it);
      if (it.photo.z <= 1) { it.photo.ox = 0; it.photo.oy = 0; }
    }
    syncSlider();
    render();
  });

  layerUpBtn.addEventListener('click', function () { moveLayer(1); });
  layerDownBtn.addEventListener('click', function () { moveLayer(-1); });
  layerTopBtn.addEventListener('click', function () { moveLayer(Infinity); });

  sliderEl.addEventListener('input', function () {
    var pct = parseInt(sliderEl.value, 10);
    sliderValEl.textContent = pct + '%';
    var it = selected();
    if (it) { it.s = pct / 100; render(); }
    else defaultScale = pct / 100;
  });

  function setZoom(pct) {
    zoomPct = Math.min(200, Math.max(50, pct));
    zoomLabelEl.textContent = zoomPct === 100 ? '1:1' : zoomPct + '%';
    stZoomEl.textContent = zoomPct + '%';
    fitStage();
  }

  function fitStage() {
    var wrap = stageFrame.parentElement;
    var availW = wrap.clientWidth - 42;
    var availH = wrap.clientHeight - 42;
    if (availW <= 0 || availH <= 0) return;
    var sc = Math.min(availW / W, availH / H) * zoomPct / 100;
    canvas.style.width = Math.floor(W * sc) + 'px';
    canvas.style.height = Math.floor(H * sc) + 'px';
  }

  document.getElementById('btn-zoomin').addEventListener('click', function () { setZoom(zoomPct + 25); });
  document.getElementById('btn-zoomout').addEventListener('click', function () { setZoom(zoomPct - 25); });

  /* ---------------- 铁盒形状 ---------------- */

  var modalTinEl = document.getElementById('modal-tin');
  var guidePending = true;

  document.getElementById('btn-tin').addEventListener('click', function () {
    modalTinEl.hidden = false;
  });
  document.getElementById('tin-cancel').addEventListener('click', function () {
    guidePending = false;
    modalTinEl.hidden = true;
  });

  function applyTin(shape) {
    var spec = TIN_SPEC[shape];
    var existing = null;
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].kind === 'tin') { existing = state.items[i]; break; }
    }
    if (existing) {
      snapshot();
      existing.shape = shape;
      existing.w = spec.w;
      existing.h = spec.h;
      selectedId = existing.id;
    } else {
      addItem('tin', { shape: shape, x: W / 2, y: Math.round(H * 0.46), r: 0, s: 1, w: spec.w, h: spec.h });
    }
    syncSlider();
    render();
  }

  var tinOpts = document.querySelectorAll('.tin-opt');
  for (var ti = 0; ti < tinOpts.length; ti++) {
    (function (btn) {
      btn.addEventListener('click', function () {
        modalTinEl.hidden = true;
        applyTin(btn.getAttribute('data-tin'));
        if (guidePending) {
          guidePending = false;
          toast('再点下方「图案」挑喜欢的贴纸吧');
        }
      });
    })(tinOpts[ti]);
  }

  /* ---------------- 图案 ---------------- */

  function addDecal(key) {
    var im = decalAssets[key];
    var aw = assetW(im), ah = assetH(im);
    var w = 320, h = 320;
    if (aw > 0) {
      var sc = 320 / Math.max(aw, ah);
      w = Math.max(60, Math.round(aw * sc));
      h = Math.max(60, Math.round(ah * sc));
    }
    addItem('decal', { decal: key, w: w, h: h, s: 1 });
  }

  var matDecals = document.querySelectorAll('.mat-decal');
  for (var mi = 0; mi < matDecals.length; mi++) {
    (function (btn) {
      btn.addEventListener('click', function () {
        var key = btn.getAttribute('data-decal');
        if (!key) return;
        addDecal(key);
      });
    })(matDecals[mi]);
  }

  /* ---------------- 自主上传素材位 ---------------- */

  var UPLOAD_SLOTS = 10;
  /* 手机原图动辄上千万像素，直接解码会撑爆内存；素材最大边压到 768 足够放大到 250% 使用 */
  var UPLOAD_MAX_SIDE = 768;
  var THUMB_MAX_SIDE = 160;
  var uploaded = {};
  var pendingSlot = 0;

  function uploadBtn(slot) {
    return materialsEl.querySelector('.mat-up[data-up="' + slot + '"]');
  }

  function buildUploadRow() {
    var row = document.getElementById('upload-row');
    for (var i = 1; i <= UPLOAD_SLOTS; i++) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'mat-decal mat-up';
      b.setAttribute('data-up', String(i));
      b.title = '上传素材 ' + i;
      var plus = document.createElement('span');
      plus.className = 'up-plus';
      plus.textContent = '+';
      var x = document.createElement('span');
      x.className = 'up-clear';
      x.setAttribute('data-clear', '1');
      x.textContent = '×';
      b.appendChild(plus);
      b.appendChild(x);
      row.appendChild(b);
    }
  }

  function tapUploadSlot(slot, target) {
    if (target && target.hasAttribute && target.hasAttribute('data-clear')) {
      resetUploadSlot(slot);
      return;
    }
    if (uploaded[slot]) { addDecal('up_' + slot); return; }
    pendingSlot = slot;
    uploadInput.click();
  }

  function resetUploadSlot(slot, silent) {
    var btn = uploadBtn(slot);
    if (!uploaded[slot] || !btn) return;
    var old = btn.getElementsByTagName('img')[0];
    if (old) btn.removeChild(old);
    btn.classList.remove('is-filled');
    delete uploaded[slot];
    delete uploadSlotSrc[slot];
    if (!silent) toast('第 ' + slot + ' 格已清空');
  }

  function fillUploadSlot(slot, src) {
    var btn = uploadBtn(slot);
    if (!btn) return;
    uploadSlotSrc[slot] = src;
    var old = btn.getElementsByTagName('img')[0];
    if (old) btn.removeChild(old);
    var im = document.createElement('img');
    im.src = src;
    im.alt = '我的素材 ' + slot;
    btn.insertBefore(im, btn.firstChild);
    btn.classList.add('is-filled');
    uploaded[slot] = true;
  }

  /* 解码一次即可：能走 ImageBitmap 就不把原图转成 base64，直接让内核异步解码 */
  function fitBox(w, h, maxSide) {
    var sc = Math.min(1, maxSide / Math.max(w, h));
    return { w: Math.max(1, Math.round(w * sc)), h: Math.max(1, Math.round(h * sc)) };
  }

  function drawScaled(src, w, h) {
    var cv = document.createElement('canvas');
    cv.width = w;
    cv.height = h;
    cv.getContext('2d').drawImage(src, 0, 0, w, h);
    return cv;
  }

  function decodeViaImg(file, cb) {
    var fr = new FileReader();
    fr.onload = function () {
      var im = new Image();
      im.decoding = 'async';
      im.onload = function () {
        var box = fitBox(im.naturalWidth, im.naturalHeight, UPLOAD_MAX_SIDE);
        cb(null, im, box.w, box.h);
      };
      im.onerror = function () { cb(new Error('decode')); };
      im.src = fr.result;
    };
    fr.onerror = function () { cb(new Error('read')); };
    fr.readAsDataURL(file);
  }

  function decodeFile(file, cb) {
    if (!window.createImageBitmap) { decodeViaImg(file, cb); return; }
    createImageBitmap(file).then(function (bmp) {
      var box = fitBox(bmp.width, bmp.height, UPLOAD_MAX_SIDE);
      cb(null, bmp, box.w, box.h);
    }).catch(function () { decodeViaImg(file, cb); });
  }

  function hasTransparent(cv) {
    var cc = cv.getContext('2d');
    var w = cv.width, h = cv.height;
    var data;
    try { data = cc.getImageData(0, 0, w, h).data; } catch (err) { return true; }
    for (var y = 0; y < h; y += 3) {
      var row = y * w * 4;
      for (var x = 0; x < w; x += 3) {
        if (data[row + x * 4 + 3] < 250) return true;
      }
    }
    return false;
  }

  /* 存档用图（恢复作品时当图源），透明留 PNG，照片用 JPEG 更省体积 */
  function assetDataUrl(cv) {
    try {
      return hasTransparent(cv) ? cv.toDataURL('image/png') : cv.toDataURL('image/jpeg', 0.84);
    } catch (err) {
      return '';
    }
  }

  function thumbOf(cv) {
    var box = fitBox(cv.width, cv.height, THUMB_MAX_SIDE);
    return drawScaled(cv, box.w, box.h).toDataURL('image/png');
  }

  uploadInput.addEventListener('change', function () {
    var file = uploadInput.files && uploadInput.files[0];
    var slot = pendingSlot;
    pendingSlot = 0;
    uploadInput.value = '';
    if (!file || !slot) return;
    decodeFile(file, function (err, src, w, h) {
      if (err) { toast('这张图片读不出来，换一张试试'); return; }
      var cv = drawScaled(src, w, h);
      if (src.close) src.close();
      /* 素材直接用缩小后的 canvas，省掉大图重新编码再解码的两次开销 */
      decalAssets['up_' + slot] = cv;
      fillUploadSlot(slot, thumbOf(cv));
      toast('第 ' + slot + ' 格好了，点它就能摆进盒子');
      setTimeout(function () {
        uploadSlotSrc[slot] = assetDataUrl(cv);
        scheduleSave();
      }, 150);
    });
  });

  /* ---------------- 工具栏 ---------------- */

  function clearAll() {
    if (!state.items.length) return;
    if (!window.confirm('确定清空画布吗？')) return;
    snapshot();
    state.items = [];
    selectedId = null;
    render();
  }

  document.getElementById('btn-clear').addEventListener('click', clearAll);
  document.getElementById('btn-undo').addEventListener('click', undo);
  document.getElementById('btn-save').addEventListener('click', saveImage);
  document.getElementById('btn-export').addEventListener('click', saveImage);

  /* ---------------- 菜单 ---------------- */

  var menus = document.querySelectorAll('.menu');
  function closeMenus() {
    for (var i = 0; i < menus.length; i++) menus[i].classList.remove('is-open');
  }
  for (var mi = 0; mi < menus.length; mi++) {
    (function (m) {
      m.querySelector('.menu-item').addEventListener('click', function (e) {
        e.stopPropagation();
        var open = m.classList.contains('is-open');
        closeMenus();
        if (!open) m.classList.add('is-open');
      });
      var drops = m.querySelectorAll('.drop-item');
      for (var di = 0; di < drops.length; di++) {
        drops[di].addEventListener('click', function (e) {
          var act = e.currentTarget.getAttribute('data-act');
          closeMenus();
          if (act === 'clear') clearAll();
          else if (act === 'new') newWork();
          else if (act === 'works') openWorks();
          else if (act === 'save') saveImage();
          else if (act === 'undo') undo();
          else if (act === 'redo') redo();
          else if (act === 'delete') {
            var it = selected();
            if (it) { snapshot(); removeItem(it.id); syncSlider(); render(); }
            else toast('先点选一个元素');
          } else if (act === 'help') modalHelpEl.hidden = false;
        });
      }
    })(menus[mi]);
  }
  document.addEventListener('click', closeMenus);
  var firstRunHelp = true;
  document.getElementById('help-ok').addEventListener('click', function () {
    modalHelpEl.hidden = true;
    /* 首次进入：看完玩法说明接着选铁盒形状 */
    if (firstRunHelp) {
      firstRunHelp = false;
      modalTinEl.hidden = false;
    }
  });

  /* ---------------- 弹窗输入 ---------------- */

  function openInput(title, hint, maxLen, initial, cb) {
    modalTitleEl.textContent = title;
    modalHintEl.textContent = hint;
    modalInputEl.value = initial || '';
    modalInputEl.maxLength = maxLen;
    modalCb = cb;
    modalEl.hidden = false;
    setTimeout(function () { modalInputEl.focus(); }, 60);
  }

  document.getElementById('modal-cancel').addEventListener('click', function () {
    modalEl.hidden = true; modalCb = null;
  });
  document.getElementById('modal-ok').addEventListener('click', function () {
    var v = modalInputEl.value.replace(/^\s+|\s+$/g, '');
    modalEl.hidden = true;
    var cb = modalCb; modalCb = null;
    if (cb) cb(v);
  });

  /* ---------------- 素材行 ---------------- */

  function syncBgSwatches() {
    var sws = materialsEl.querySelectorAll('.mat-bg');
    for (var i = 0; i < sws.length; i++) {
      var isActive = sws[i].getAttribute('data-bg') === state.bg ||
                     (state.bg === 'custom' && sws[i].id === 'bg-upload');
      sws[i].classList.toggle('is-active', isActive);
    }
  }

  materialsEl.addEventListener('click', function (e) {
    var btn = e.target;
    while (btn && btn !== materialsEl && btn.tagName !== 'BUTTON') btn = btn.parentElement;
    if (!btn || btn === materialsEl) return;

    if (btn.id === 'bg-upload') {
      if (customBgImg && state.bg !== 'custom') {
        snapshot(); state.bg = 'custom'; syncBgSwatches(); render();
      } else {
        bgInput.click();
      }
      return;
    }
    var bg = btn.getAttribute('data-bg');
    if (bg) {
      if (bg !== state.bg) { snapshot(); state.bg = bg; syncBgSwatches(); render(); }
      return;
    }
    var up = btn.getAttribute('data-up');
    if (up) { tapUploadSlot(parseInt(up, 10), e.target); return; }
    var add = btn.getAttribute('data-add');
    if (!add) return;

    if (add === 'stStar' || add === 'stHeart' || add === 'stSeal' ||
             add === 'stPetal' || add === 'stBow' || add === 'stKeychain') addItem(add);
    else if (add && add.indexOf('bead_') === 0) addItem('tile', { ch: add.slice(5) });
    else if (add === 'script') {
      openInput('花体标题', '英文花体更有感觉，最多 16 字符', 16, '', function (v) {
        if (v) addItem('script', { text: v, w: measureTextItem('script', v), h: 150 });
      });
    }
    else if (add === 'label') {
      openInput('短句标签', '如 사랑해 / 나도 / Lucky Me!', 16, '', function (v) {
        if (v) addItem('label', { text: v, w: measureTextItem('label', v), h: 68, shape: 'rect' });
      });
    }
    else if (add === 'rectpol' || add === 'polaroid' || add === 'strip' || add === 'heart' || add === 'stamp' ||
             add === 'cam1' || add === 'cam2' || add === 'cam3') {
      pendingFrame = add;
      if (add === 'strip') toast('连拍条：请在相册中选择 3 张照片');
      fileInput.click();
    }
  });

  fileInput.addEventListener('change', function () {
    var files = fileInput.files ? Array.prototype.slice.call(fileInput.files) : [];
    var kind = pendingFrame || 'polaroid';
    pendingFrame = null;
    fileInput.value = '';
    if (!files.length) return;
    if (kind === 'strip') {
      if (files.length < 3) {
        toast('连拍条需要选择 3 张照片，请重新选择');
        return;
      }
      var keys = [];
      for (var i = 0; i < 3; i++) {
        var k = 'u' + nextId + '_' + i;
        registerUserImage(k, files[i]);
        keys.push(k);
      }
      addItem('strip', { imgKeys: keys, s: 1.4 });
      return;
    }
    var key = 'u' + nextId;
    registerUserImage(key, files[0]);
    addItem(kind, { imgKey: key, s: 1.4 });
  });

  bgInput.addEventListener('change', function () {
    var file = bgInput.files && bgInput.files[0];
    bgInput.value = '';
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      var im = new Image();
      im.onload = function () {
        customBgImg = im;
        customBgSrc = reader.result;
        snapshot();
        state.bg = 'custom';
        var cell = document.getElementById('bg-upload');
        var old = cell.getElementsByTagName('img')[0];
        if (old) cell.removeChild(old);
        var thumb = document.createElement('img');
        thumb.src = reader.result;
        thumb.alt = '自定义背景';
        cell.insertBefore(thumb, cell.firstChild);
        syncBgSwatches();
        render();
      };
      im.src = reader.result;
    };
    reader.readAsDataURL(file);
  });

  /* ---------------- 保存 / 导出 ---------------- */

  function saveImage() {
    var dataUrl;
    try {
      dataUrl = canvas.toDataURL('image/png');
    } catch (err) {
      toast('导出失败：画布无法导出');
      return;
    }
    var mt = window.xhs && window.xhs.miniTool;
    if (mt && typeof mt.saveImageToPhotosAlbum === 'function') {
      saveViaContainer(mt, dataUrl);
    } else {
      exportPreviewEl.src = dataUrl;
      modalExportEl.hidden = false;
    }
  }

  function saveViaContainer(mt, dataUrl) {
    var doSave = function (filePath) {
      mt.saveImageToPhotosAlbum({ filePath: filePath }).then(function () {
        toast('已保存到相册');
      }).catch(function (e) {
        toast('保存失败：' + ((e && e.errMsg) || '请重试'));
      });
    };
    if (typeof mt.writeTempFile === 'function') {
      mt.writeTempFile({ data: dataUrl }).then(function (r) {
        doSave((r && r.filePath) || dataUrl);
      }).catch(function () {
        doSave(dataUrl);
      });
    } else {
      doSave(dataUrl);
    }
  }

  document.getElementById('export-close').addEventListener('click', function () {
    modalExportEl.hidden = true;
    exportPreviewEl.removeAttribute('src');
  });

  /* ---------------- 视口高度 ---------------- */

  function updateAppHeight() {
    var h = window.visualViewport ? window.visualViewport.height : window.innerHeight;
    document.documentElement.style.setProperty('--app-height', h + 'px');
  }
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', updateAppHeight);
  }
  window.addEventListener('resize', updateAppHeight);
  window.addEventListener('resize', fitStage);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', fitStage);
  }
  updateAppHeight();

  /* ---------------- 启动 ---------------- */

  (function buildBeadRow() {
    var row = document.getElementById('bead-row');
    for (var i = 0; i < BEADS.length; i++) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'mat-btn mat-bead';
      b.setAttribute('data-add', 'bead_' + BEADS[i]);
      var im = document.createElement('img');
      im.src = './assets/tiles/tile_' + BEADS[i] + '.png';
      im.alt = BEADS[i];
      b.appendChild(im);
      row.appendChild(b);
    }
  })();
  (function buildBgRow() {
    var row = document.getElementById('bg-row');
    for (var i = 0; i < BGS.length; i++) {
      var b = document.createElement('button');
      b.type = 'button';
      b.className = 'mat-btn mat-bg';
      b.setAttribute('data-bg', BGS[i]);
      b.title = '背景 ' + (i + 1);
      var im = document.createElement('img');
      im.src = './assets/bg/' + BGS[i] + '.jpg';
      im.alt = '背景 ' + (i + 1);
      b.appendChild(im);
      row.appendChild(b);
    }
    var up = document.createElement('button');
    up.type = 'button';
    up.className = 'mat-btn mat-bg mat-bg-upload';
    up.id = 'bg-upload';
    up.title = '上传自定义背景';
    var sp = document.createElement('span');
    sp.textContent = '+上传';
    up.appendChild(sp);
    row.appendChild(up);
    syncBgSwatches();
  })();
  /* ---------------- 多作品存档 / 恢复 ---------------- */

  var WORKS_KEY = 'tincase_works_v2';
  var LEGACY_KEY = 'tincase_work_v1';
  var worksList = [];      /* [{id,name,savedAt,thumb,data:{bg,items,userImages,uploadSlots,customBg}}] */
  var currentWorkId = null;
  var currentWorkName = '作品 1';
  var worksModalEl = document.getElementById('modal-works');
  var worksListEl = document.getElementById('works-list');
  var userImageSrc = {};   /* 相框照片 key -> dataURL */
  var uploadSlotSrc = {};  /* 上传槽 slot -> dataURL */
  var customBgSrc = null;  /* 自定义背景 dataURL */
  var saveTimer = 0;
  var saveWarned = false;

  function scheduleSave() {
    if (saveTimer) return;
    saveTimer = setTimeout(function () {
      saveTimer = 0;
      saveWork();
    }, 600);
  }

  function currentWork() {
    for (var i = 0; i < worksList.length; i++) {
      if (worksList[i].id === currentWorkId) return worksList[i];
    }
    return null;
  }

  function makeThumb() {
    try {
      var cv = document.createElement('canvas');
      cv.width = 180; cv.height = 240;
      var c2 = cv.getContext('2d');
      c2.drawImage(canvas, 0, 0, W, H, 0, 0, 180, 240);
      return cv.toDataURL('image/jpeg', 0.6);
    } catch (err) { return ''; }
  }

  function persistWorks() {
    try {
      localStorage.setItem(WORKS_KEY, JSON.stringify({ works: worksList, currentId: currentWorkId }));
    } catch (err) {
      if (!saveWarned) {
        saveWarned = true;
        toast('作品太多或太大，本次改动可能无法自动保存');
      }
    }
  }

  function saveWork() {
    var w = currentWork();
    if (!w) return;
    w.name = currentWorkName;
    w.savedAt = Date.now();
    w.thumb = makeThumb();
    w.data = {
      bg: state.bg,
      items: state.items,
      userImages: userImageSrc,
      uploadSlots: uploadSlotSrc,
      customBg: customBgSrc
    };
    persistWorks();
  }

  /* 读取作品库；首次运行时把旧版单作品存档迁移进来 */
  function loadWorksStore() {
    var raw = null;
    try { raw = localStorage.getItem(WORKS_KEY); } catch (err) {}
    if (raw) {
      try {
        var d = JSON.parse(raw);
        if (d && d.works && d.works.length) {
          worksList = d.works;
          var cid = d.currentId;
          for (var i = 0; i < worksList.length; i++) {
            if (worksList[i].id === cid) return cid;
          }
          return worksList[0].id;
        }
      } catch (err) {}
    }
    var legacy = null;
    try { legacy = localStorage.getItem(LEGACY_KEY); } catch (err) {}
    var data = null;
    if (legacy) { try { data = JSON.parse(legacy); } catch (err) {} }
    var w = {
      id: 'w' + Date.now().toString(36),
      name: '作品 1',
      savedAt: Date.now(),
      thumb: '',
      data: data && data.items ? data : { bg: 'bg_1', items: [], userImages: {}, uploadSlots: {}, customBg: null }
    };
    worksList = [w];
    return w.id;
  }

  /* 把一份作品数据应用到画布（照片 / 上传槽 / 自定义背景 / 元素） */
  function applyWorkData(data) {
    /* 相框照片 */
    var uimgs = data.userImages || {};
    for (var uk in uimgs) {
      if (!Object.prototype.hasOwnProperty.call(uimgs, uk)) continue;
      (function (key, src) {
        var entry = { img: new Image(), loaded: false };
        entry.img.onload = function () { entry.loaded = true; render(); };
        entry.img.src = src;
        imgPool[key] = entry;
      })(uk, uimgs[uk]);
    }
    userImageSrc = uimgs;

    /* 上传槽 */
    var slots = data.uploadSlots || {};
    for (var s in slots) {
      if (!Object.prototype.hasOwnProperty.call(slots, s)) continue;
      (function (slot, src) {
        var im = new Image();
        im.onload = function () {
          decalAssets['up_' + slot] = im;
          fillUploadSlot(parseInt(slot, 10), src);
          render();
        };
        im.src = src;
      })(s, slots[s]);
    }
    uploadSlotSrc = slots;

    /* 自定义背景 */
    if (data.customBg) {
      customBgSrc = data.customBg;
      var bim = new Image();
      bim.onload = function () {
        customBgImg = bim;
        var cell = document.getElementById('bg-upload');
        if (cell) {
          var old = cell.getElementsByTagName('img')[0];
          if (old) cell.removeChild(old);
          var thumb = document.createElement('img');
          thumb.src = customBgSrc;
          thumb.alt = '自定义背景';
          cell.insertBefore(thumb, cell.firstChild);
        }
        syncBgSwatches();
        render();
      };
      bim.src = data.customBg;
      state.bg = 'custom';
    } else {
      customBgSrc = null;
      state.bg = data.bg || 'bg_1';
    }

    /* 元素与 id 序号 */
    state.items = data.items;
    var maxId = 0;
    for (var i = 0; i < state.items.length; i++) {
      if (state.items[i].id > maxId) maxId = state.items[i].id;
    }
    nextId = maxId + 1;
    return true;
  }

  function restoreWork() {
    currentWorkId = loadWorksStore();
    var w = currentWork();
    if (!w) return false;
    currentWorkName = w.name || '作品 1';
    var data = w.data;
    if (!data || !data.items || !data.items.length) return false;
    return applyWorkData(data);
  }

  /* ---------------- 作品管理 ---------------- */

  function fmtDate(ts) {
    var d = new Date(ts);
    return (d.getMonth() + 1) + '月' + d.getDate() + '日 ' +
      ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
  }

  function openWorks() {
    renderWorksList();
    worksModalEl.hidden = false;
  }

  function renderWorksList() {
    worksListEl.innerHTML = '';
    var shown = [];
    for (var i = 0; i < worksList.length; i++) {
      var d = worksList[i].data;
      if (d && d.items && d.items.length) shown.push(worksList[i]);
    }
    if (!shown.length) {
      var tip = document.createElement('div');
      tip.className = 'works-empty';
      tip.textContent = '还没有保存的作品，做完一张会自动出现在这里';
      worksListEl.appendChild(tip);
      return;
    }
    for (var j = 0; j < shown.length; j++) {
      (function (w) {
        var card = document.createElement('div');
        card.className = 'work-card' + (w.id === currentWorkId ? ' is-current' : '');
        var th = document.createElement('img');
        th.className = 'work-thumb';
        if (w.thumb) { th.src = w.thumb; }
        else {
          var ph = document.createElement('canvas'); ph.width = 90; ph.height = 120;
          th.src = ph.toDataURL();
        }
        th.alt = w.name;
        card.appendChild(th);
        var meta = document.createElement('div');
        meta.className = 'work-meta';
        var nm = document.createElement('span');
        nm.className = 'work-name';
        nm.textContent = (w.id === currentWorkId ? '✏️ ' : '') + w.name;
        meta.appendChild(nm);
        var dt = document.createElement('span');
        dt.className = 'work-date';
        dt.textContent = fmtDate(w.savedAt);
        meta.appendChild(dt);
        card.appendChild(meta);
        var btns = document.createElement('div');
        btns.className = 'work-btns';
        if (w.id !== currentWorkId) {
          var loadBtn = document.createElement('button');
          loadBtn.className = 'tool-btn tool-btn-primary';
          loadBtn.type = 'button';
          loadBtn.textContent = '载入';
          loadBtn.addEventListener('click', function () { loadWorkById(w.id); });
          btns.appendChild(loadBtn);
        } else {
          var cur = document.createElement('span');
          cur.className = 'work-cur-tag';
          cur.textContent = '编辑中';
          btns.appendChild(cur);
        }
        var rnBtn = document.createElement('button');
        rnBtn.className = 'tool-btn';
        rnBtn.type = 'button';
        rnBtn.textContent = '改名';
        rnBtn.addEventListener('click', function () { renameWork(w.id); });
        btns.appendChild(rnBtn);
        var delBtn = document.createElement('button');
        delBtn.className = 'tool-btn';
        delBtn.type = 'button';
        delBtn.textContent = '删除';
        delBtn.addEventListener('click', function () { deleteWork(w.id); });
        btns.appendChild(delBtn);
        card.appendChild(btns);
        worksListEl.appendChild(card);
      })(shown[j]);
    }
  }

  function loadWorkById(id) {
    var w = null;
    for (var i = 0; i < worksList.length; i++) {
      if (worksList[i].id === id) { w = worksList[i]; break; }
    }
    if (!w) return;
    if (w.id === currentWorkId) { worksModalEl.hidden = true; return; }
    /* 清掉当前作品的上传槽与自定义背景缩略图，避免残留到新作品 */
    clearUploadSlotsUi();
    var bgCell = document.getElementById('bg-upload');
    if (bgCell) {
      var oi = bgCell.getElementsByTagName('img')[0];
      if (oi) bgCell.removeChild(oi);
    }
    applyWorkData(w.data);
    currentWorkId = id;
    currentWorkName = w.name || '作品 1';
    undoStack = [];
    redoStack = [];
    selectedId = null;
    photoEdit = false;
    photoEditItemId = null;
    syncBgSwatches();
    syncSlider();
    setZoom(100);
    render();
    worksModalEl.hidden = true;
    toast('已打开「' + currentWorkName + '」');
  }

  function renameWork(id) {
    var w = null;
    for (var i = 0; i < worksList.length; i++) {
      if (worksList[i].id === id) { w = worksList[i]; break; }
    }
    if (!w) return;
    openInput('作品名称', '最多 12 个字', 12, w.name, function (v) {
      if (!v) return;
      w.name = v;
      if (w.id === currentWorkId) currentWorkName = v;
      persistWorks();
      renderWorksList();
      toast('已改名为「' + v + '」');
    });
  }

  function deleteWork(id) {
    var w = null;
    for (var i = 0; i < worksList.length; i++) {
      if (worksList[i].id === id) { w = worksList[i]; break; }
    }
    if (!w) return;
    if (!window.confirm('确定删除「' + w.name + '」吗？删除后无法恢复。')) return;
    for (var i = 0; i < worksList.length; i++) {
      if (worksList[i].id === id) { worksList.splice(i, 1); break; }
    }
    if (id === currentWorkId) {
      startBlankWork();
    }
    persistWorks();
    renderWorksList();
    toast('已删除');
  }

  function clearUploadSlotsUi() {
    for (var i = 1; i <= UPLOAD_SLOTS; i++) {
      resetUploadSlot(i, true);
      delete decalAssets['up_' + i];
    }
  }

  function clearCanvasUi() {
    state.items = [];
    selectedId = null;
    nextId = 1;
    userImageSrc = {};
    uploadSlotSrc = {};
    customBgSrc = null;
    customBgImg = null;
    undoStack = [];
    redoStack = [];
    photoEdit = false;
    photoEditItemId = null;
    clearUploadSlotsUi();
    var cell = document.getElementById('bg-upload');
    if (cell) {
      var old = cell.getElementsByTagName('img')[0];
      if (old) cell.removeChild(old);
    }
  }

  /* 新建空白作品（当前作品已自动存档，不会丢失） */
  function newWork() {
    var w = {
      id: 'w' + Date.now().toString(36),
      name: '作品 ' + (worksList.length + 1),
      savedAt: Date.now(),
      thumb: '',
      data: { bg: 'bg_1', items: [], userImages: {}, uploadSlots: {}, customBg: null }
    };
    worksList.push(w);
    currentWorkId = w.id;
    currentWorkName = w.name;
    clearCanvasUi();
    state.bg = 'bg_1';
    syncBgSwatches();
    syncSlider();
    setZoom(100);
    render();
    persistWorks();
    toast('新作品开始啦，旧作品已自动保存');
  }

  /* 删除当前作品后的兜底：建一个空白当前作品但不弹提示 */
  function startBlankWork() {
    var w = {
      id: 'w' + Date.now().toString(36),
      name: '作品 ' + (worksList.length + 1),
      savedAt: Date.now(),
      thumb: '',
      data: { bg: 'bg_1', items: [], userImages: {}, uploadSlots: {}, customBg: null }
    };
    worksList.push(w);
    currentWorkId = w.id;
    currentWorkName = w.name;
    clearCanvasUi();
    state.bg = 'bg_1';
    syncBgSwatches();
    syncSlider();
    setZoom(100);
    render();
  }

  document.getElementById('works-new').addEventListener('click', function () {
    newWork();
    worksModalEl.hidden = true;
  });
  document.getElementById('works-close').addEventListener('click', function () {
    worksModalEl.hidden = true;
  });

  buildUploadRow();
  preloadBgs();
  preloadTiles();
  preloadTins();
  preloadCams();
  preloadDecals();
  preloadObjs();
  undoStack = [];
  selectedId = null;
  var restored = restoreWork();
  syncSlider();
  setZoom(100);
  render();
  if (restored) {
    /* 回访用户：直接回到上次作品，不再重复引导 */
    toast('已恢复上次进度 ✓');
  } else {
    /* 首次进入引导：先看玩法说明，再选铁盒形状 */
    modalHelpEl.hidden = false;
  }
})();
